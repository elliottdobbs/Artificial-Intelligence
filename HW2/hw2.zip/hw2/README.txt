Elliott Dobbs
HW2 Artificial Intelligence
823004322

Problem 1:

	Compile with 	"g++ -std=c++17 hw2pr1.cpp"
	Run with 	"./a.out <hw2pr1_data.txt" 	for UNIX redirection
	or 	 	"./a.out" 			for inputting a tree manually


Problem 2:

	Compile with 	"g++ -std=c++17 hw2pr2.cpp"
	Run with 	"./a.out <hw2pr2_data.txt" 	for UNIX redirection
	or 	 	"./a.out" 			for inputting a tree manually


Problem 3:
	
	Compile with	"g++ -std=c++17 hw2pr3.cpp"
	Run with 	"./a.out"			to input a filename manually
	or 		"./a.out <hw2pr3_input.txt"	for UNIX redirection of a file that simply contains the name of the data file to be used